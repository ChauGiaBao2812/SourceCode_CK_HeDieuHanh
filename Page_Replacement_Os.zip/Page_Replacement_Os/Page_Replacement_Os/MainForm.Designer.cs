﻿namespace Page_Replacement_Os
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.workspace = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.txtGiaiThuat = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtThoiGian = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.btnKiemTra = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.txtChuoiTrang = new System.Windows.Forms.TextBox();
            this.txtSoKhungTrang = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtSoTrangAo = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtKetQua = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LightSteelBlue;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1537, 100);
            this.panel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.LightSteelBlue;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label1.Location = new System.Drawing.Point(192, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1188, 45);
            this.label1.TabIndex = 2;
            this.label1.Text = "CHƯƠNG TRÌNH MINH HỌA GIẢI THUẬT THAY THẾ TRANG";
            // 
            // workspace
            // 
            this.workspace.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.workspace.Dock = System.Windows.Forms.DockStyle.Right;
            this.workspace.Location = new System.Drawing.Point(308, 100);
            this.workspace.Name = "workspace";
            this.workspace.Size = new System.Drawing.Size(1229, 616);
            this.workspace.TabIndex = 1;
            this.workspace.Paint += new System.Windows.Forms.PaintEventHandler(this.workspace_Paint);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(10, 394);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(111, 25);
            this.label7.TabIndex = 18;
            this.label7.Text = "Giải thuật: ";
            // 
            // txtGiaiThuat
            // 
            this.txtGiaiThuat.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGiaiThuat.FormattingEnabled = true;
            this.txtGiaiThuat.Items.AddRange(new object[] {
            "FIFO",
            "LRU",
            "OPT"});
            this.txtGiaiThuat.Location = new System.Drawing.Point(195, 394);
            this.txtGiaiThuat.Name = "txtGiaiThuat";
            this.txtGiaiThuat.Size = new System.Drawing.Size(92, 28);
            this.txtGiaiThuat.TabIndex = 0;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(10, 468);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(172, 25);
            this.label6.TabIndex = 17;
            this.label6.Text = "Thời gian chạy(s):";
            // 
            // txtThoiGian
            // 
            this.txtThoiGian.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtThoiGian.Location = new System.Drawing.Point(195, 460);
            this.txtThoiGian.Name = "txtThoiGian";
            this.txtThoiGian.Size = new System.Drawing.Size(92, 33);
            this.txtThoiGian.TabIndex = 13;
            this.txtThoiGian.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtThoiGian.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtThoiGian_KeyPress);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(6, 599);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(125, 25);
            this.label5.TabIndex = 16;
            this.label5.Text = "Số trang lỗi: ";
            // 
            // btnKiemTra
            // 
            this.btnKiemTra.BackColor = System.Drawing.Color.SteelBlue;
            this.btnKiemTra.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnKiemTra.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnKiemTra.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnKiemTra.Location = new System.Drawing.Point(56, 522);
            this.btnKiemTra.Name = "btnKiemTra";
            this.btnKiemTra.Size = new System.Drawing.Size(188, 56);
            this.btnKiemTra.TabIndex = 14;
            this.btnKiemTra.Text = "Kiểm tra";
            this.btnKiemTra.UseVisualStyleBackColor = false;
            this.btnKiemTra.Click += new System.EventHandler(this.btnKiemTra_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(7, 201);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(168, 25);
            this.label4.TabIndex = 12;
            this.label4.Text = "Nhập chuỗi trang:";
            // 
            // txtChuoiTrang
            // 
            this.txtChuoiTrang.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtChuoiTrang.Location = new System.Drawing.Point(5, 245);
            this.txtChuoiTrang.Name = "txtChuoiTrang";
            this.txtChuoiTrang.Size = new System.Drawing.Size(282, 33);
            this.txtChuoiTrang.TabIndex = 11;
            // 
            // txtSoKhungTrang
            // 
            this.txtSoKhungTrang.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSoKhungTrang.Location = new System.Drawing.Point(195, 319);
            this.txtSoKhungTrang.Name = "txtSoKhungTrang";
            this.txtSoKhungTrang.Size = new System.Drawing.Size(92, 33);
            this.txtSoKhungTrang.TabIndex = 10;
            this.txtSoKhungTrang.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtSoKhungTrang.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSoKhungTrang_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(10, 327);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(154, 25);
            this.label2.TabIndex = 9;
            this.label2.Text = "Số khung trang: ";
            // 
            // txtSoTrangAo
            // 
            this.txtSoTrangAo.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSoTrangAo.Location = new System.Drawing.Point(195, 120);
            this.txtSoTrangAo.Name = "txtSoTrangAo";
            this.txtSoTrangAo.Size = new System.Drawing.Size(92, 33);
            this.txtSoTrangAo.TabIndex = 8;
            this.txtSoTrangAo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtSoTrangAo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSoTrangAo_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(10, 128);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(117, 25);
            this.label3.TabIndex = 7;
            this.label3.Text = "Số trang ảo:";
            // 
            // txtKetQua
            // 
            this.txtKetQua.Font = new System.Drawing.Font("Times New Roman", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtKetQua.Location = new System.Drawing.Point(11, 627);
            this.txtKetQua.Name = "txtKetQua";
            this.txtKetQua.Size = new System.Drawing.Size(188, 33);
            this.txtKetQua.TabIndex = 15;
            this.txtKetQua.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1537, 716);
            this.Controls.Add(this.workspace);
            this.Controls.Add(this.btnKiemTra);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtGiaiThuat);
            this.Controls.Add(this.txtKetQua);
            this.Controls.Add(this.txtSoTrangAo);
            this.Controls.Add(this.txtChuoiTrang);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtSoKhungTrang);
            this.Controls.Add(this.txtThoiGian);
            this.Name = "MainForm";
            this.Text = "Page Replace Program";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel workspace;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtThoiGian;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnKiemTra;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtChuoiTrang;
        private System.Windows.Forms.TextBox txtSoKhungTrang;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtSoTrangAo;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox txtGiaiThuat;
        private System.Windows.Forms.TextBox txtKetQua;
    }
}

